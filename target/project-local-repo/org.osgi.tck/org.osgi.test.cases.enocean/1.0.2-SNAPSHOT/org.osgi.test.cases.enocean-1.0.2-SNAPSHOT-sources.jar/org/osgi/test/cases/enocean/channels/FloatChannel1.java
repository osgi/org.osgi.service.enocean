/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.test.cases.enocean.channels;

import org.osgi.service.enocean.EnOceanChannel;
import org.osgi.test.cases.enocean.utils.Fixtures;
import org.osgi.test.cases.enocean.utils.Utils;

/**
 * @author $Id: cba7a3f2c3654e5e9ef7404c216443f16587ed70 $
 */
public class FloatChannel1 implements EnOceanChannel {

	private byte	b0;

	public String getChannelId() {
		return Fixtures.CHANNEL_ID;
	}

	public void setRawValue(byte[] rawValue) {
		b0 = rawValue[0];
	}

	public int getSize() {
		return 8;
	}

	public byte[] getRawValue() {
		return Utils.byteToBytes(b0);
	}

	public int getOffset() {
		return 16;
	}

}
