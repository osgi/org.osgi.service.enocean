/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.test.cases.enocean.serial;

import org.osgi.test.cases.enocean.utils.ByteSerializable;

/**
 * @author $Id: 114801c04e979dbb184dd5a06d4f09d16a2ba107 $
 */
public class TrivialByteSerializable implements ByteSerializable {

	private byte[]	data;

	/**
	 * @param data
	 */
	public TrivialByteSerializable(byte[] data) {
		this.data = data;
	}

	public byte[] getBytes() {
		return data;
	}

}
