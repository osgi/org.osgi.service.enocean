/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.test.cases.enocean.channels;

import org.osgi.service.enocean.EnOceanChannel;

/**
 * @author $Id: 4502618a94f3c07c00a5ccd02ddc268e58b986c8 $
 */
public class Channel04 implements EnOceanChannel {

	private byte[]	rawValue;

	public String getChannelId() {
		return "SA_00";
	}

	public int getOffset() {
		return 7;
	}

	public int getSize() {
		return 1;
	}

	public byte[] getRawValue() {
		return rawValue;
	}

	public void setRawValue(byte[] rawValue) {
		this.rawValue = rawValue;
	}

}
