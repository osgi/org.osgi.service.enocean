/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.test.cases.enocean;

/**
 * This class contains:
 * 
 * - testSignatures, cf. testSignatures() method from org.osgi.test.support.
 * signature.SignatureTestCase.
 * 
 * @author $Id: 12f353e8e14ed36feb8fa1a0d2fa8d7ae883d52c $
 */
public class SignatureTestCase extends org.osgi.test.support.signature.SignatureTestCase {

	// see org.osgi.test.support.signature.SignatureTestCase.

}
