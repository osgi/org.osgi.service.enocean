/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.impl.service.enocean;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.impl.service.enocean.basedriver.EnOceanBaseDriver;

/**
 * Reference Implementation's Activator.
 */
public class EnOceanBundleActivator implements BundleActivator {

	private EnOceanBaseDriver	basedriver;

	@Override
	public void start(BundleContext bc) {
		basedriver = new EnOceanBaseDriver(bc);
		basedriver.start();
	}

	@Override
	public void stop(BundleContext bc) {
		basedriver.stop();
	}
}
